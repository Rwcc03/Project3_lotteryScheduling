#include "kernel/types.h"
#include "kernel/stat.h"
#include "kernel/pstat.h"
#include "user/user.h"



int
main(int argc, char **argv)
{
    struct pstat ps;
    settickets(4000);
    getpinfo(&ps);
    
    for(int i = 0; i < NPROC; i++){
        
        printf("tickets and ticks: %d %d\n", ps.tickets[i], ps.ticks[i]);
    }






}